package com.darkhack

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null
    // Updated Registration URL
    private val registerUrl = "https://www.jaiclub39.com/#/register?invitationCode=431714079459"
    // Updated Main URL
    private val mainUrl = "https://www.jaiclub39.com/#/main"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webView)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.userAgentString = "Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

        // FIX: Mixed content block hone se aksar white/blank page dikhta hai
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            webView.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        // FIX: Kam RAM wale phones me hardware layer render issue (black page) fix karta hai
        webView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        webView.settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT

        // JavaScript aur Kotlin ko connect karne ka bridge
        webView.addJavascriptInterface(WebAppInterface(), "AndroidApp")

        // App start hote hi pehli aawaz play karega
        playVoice()

        webView.webViewClient = object : WebViewClient() {

            // FIX: Page load fail hone par (no internet, DNS fail, timeout) white/blank
            // page dikhne ki jagah retry karega aur user ko batayega
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    Toast.makeText(this@MainActivity, "Connection issue, retrying...", Toast.LENGTH_SHORT).show()
                    view?.postDelayed({ view.loadUrl(view.url ?: registerUrl) }, 2000)
                }
            }

            // FIX: WebView renderer crash hone par (low-RAM phones me common) black page
            // dikhne ki jagah activity ko safely recreate karega
            override fun onRenderProcessGone(view: WebView?, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
                if (view != null) {
                    (view.parent as? android.view.ViewGroup)?.removeView(view)
                    view.destroy()
                }
                recreate()
                return true
            }

            // YAHAN PAR NAYA TELEGRAM / INTENT FIX ADD KIYA HAI
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false

                // Agar link http ya https hai (Normal website), toh usko WebView me hi khulne do
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false 
                }

                // Agar koi custom scheme hai jaise 'tg://' (Telegram), toh usko external app me open karo
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    view?.context?.startActivity(intent)
                    return true // True matlab humne handle kar liya
                } catch (e: Exception) {
                    // Agar user ke phone me app install hi nahi hai
                    Toast.makeText(view?.context, "App not installed on your phone!", Toast.LENGTH_SHORT).show()
                    return true
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                CookieManager.getInstance().flush()

                // Tera main hack UI injection code
                val jsCode = """
                    javascript:(function() {
                        document.addEventListener('click', function(e) {
                            if(window.location.href.toLowerCase().includes('register')) {
                                // FIX: hamburger menu button (☰) is corner-block region ke andar hi
                                // aata tha isliye register page pe click hi nahi hota tha.
                                // Ab agar click hamburger button ya uske parent pe hai, to block nahi karega.
                                if (e.target.closest && e.target.closest('#btn-open-menu')) {
                                    return;
                                }
                                if(e.clientX < 80 && e.clientY < 80) {
                                    e.stopPropagation();
                                    e.preventDefault();
                                }
                            }
                        }, true);
                        
                        setInterval(function() {
                            var currentLink = window.location.href.toLowerCase();
                            if(currentLink.includes('login')) {
                                // Login page aate hi warning voice chalayega
                                AndroidApp.playWarningVoice();
                                window.location.href = '$registerUrl';
                            }
                        }, 1000);
                        
                        // ⚡ PREMIUM CLEAN PRO INJECTOR (Dark Hack UI)
                        if(!document.getElementById('clean-pro-banner')) {
                            var style = document.createElement('style');
                            style.innerHTML = `
                                body { padding-top: 220px !important; }
                                #clean-pro-banner { position: fixed; top: 0; left: 0; width: 100%; height: 205px; background: linear-gradient(180deg, #020202 0%, #0a0a0c 100%); clip-path: polygon(0 0, 100% 0, 100% 90%, 85% 100%, 15% 100%, 0 90%); box-shadow: 0 10px 20px rgba(0, 0, 0, 0.9); z-index: 9999998; display: flex; flex-direction: column; align-items: center; font-family: 'Segoe UI', Tahoma, sans-serif; border-bottom: 2px solid #222; overflow: hidden; }
                                #matrix-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; opacity: 0.6; }
                                .hud-top-bar, .hud-core, #hud-glow-line { position: relative; z-index: 1; width: 100%; }
                                #hud-glow-line { position: absolute; bottom: 0; left: 15%; width: 70%; height: 2px; background: #00ff41; box-shadow: 0 0 10px #00ff41; }
                                .hud-top-bar { display: flex; justify-content: space-between; align-items: center; padding: 8px 15px; background: rgba(0, 0, 0, 0.6); border-bottom: 1px solid rgba(0, 255, 65, 0.2); }
                                .left-group { display: flex; align-items: center; gap: 10px; }
                                .hud-menu-btn { color: #fff; font-size: 24px; font-weight: bold; cursor: pointer; }
                                .dev-badge { color: #fff; font-size: 11px; font-weight: 900; letter-spacing: 1px; background: rgba(0,255,65,0.1); padding: 4px 10px; border-radius: 4px; border: 1px solid #00ff41; text-transform: uppercase; box-shadow: 0 0 5px rgba(0,255,65,0.3); }
                                .dev-badge span { color: #00ff41; }
                                .hud-status { display: flex; align-items: center; gap: 6px; color: #fff; font-size: 11px; font-weight: 900; letter-spacing: 1px; text-transform: uppercase;}
                                .pulse-dot { width: 8px; height: 8px; background: #00ff41; border-radius: 50%; animation: blink 1s infinite alternate; box-shadow: 0 0 8px #00ff41;}
                                @keyframes blink { 0% { opacity: 0.3; } 100% { opacity: 1; } }
                                .hud-core { width: 95%; flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding-bottom: 10px;}
                                .sys-hang-title { display: flex; align-items: center; justify-content: center; gap: 15px; color: #fff; font-size: 20px; font-style: italic; font-weight: 900; letter-spacing: 2px; margin-bottom: 12px; width: 100%; text-shadow: 0 0 5px #fff; }
                                @keyframes flyMoney { 0% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-10px) rotate(15deg) scale(1.1); } 100% { transform: translateY(0px) rotate(0deg); } }
                                .money-icon { font-size: 30px; animation: flyMoney 1.5s infinite ease-in-out; filter: drop-shadow(0 0 5px rgba(0,255,0,0.5)); }
                                .deposit-btn { background: #ff0000; color: #fff; font-weight: 900; font-size: 15px; padding: 10px 40px; border: none; cursor: pointer; text-transform: uppercase; box-shadow: 0 4px 15px rgba(255,0,0,0.6); margin-bottom: 10px; transition: transform 0.2s, background 0.2s; letter-spacing: 1px; border-radius: 3px; }
                                .deposit-btn:active { transform: scale(0.95); background: #cc0000; }
                                .period-text { color: #00ff41; font-size: 13px; font-weight: bold; margin-bottom: 8px; letter-spacing: 1px; }
                                .name-text { color: #f0a500; font-size: 13px; font-weight: 900; text-transform: uppercase; letter-spacing: 1px;}
                                .hud-result-wrap { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 5px; width: 100%; margin-bottom: 5px; }
                                .hud-res-text { font-size: 40px; font-weight: 900; letter-spacing: 5px; text-transform: uppercase; line-height: 1; transition: all 0.3s ease; }
                                .hud-nums-wrap { display: flex; gap: 15px; margin-top: 2px; margin-bottom: 5px; }
                                .h-ball { width: 32px; height: 32px; background: rgba(0,0,0,0.8); border: 2px solid; display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 900; border-radius: 50%; font-family: monospace; transition: all 0.3s ease; }
                                #sci-sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: linear-gradient(135deg, rgba(2, 6, 18, 0.98), rgba(8, 15, 30, 0.98)); border-right: 2px solid #00ff41; box-shadow: 15px 0 40px rgba(0, 255, 65, 0.2); z-index: 9999999; transform: translateX(-100%); transition: transform 0.4s cubic-bezier(0.25, 1, 0.5, 1); display: flex; flex-direction: column; font-family: 'Segoe UI', Tahoma, sans-serif; overflow-y: auto; }
                                #sci-sidebar.open { transform: translateX(0); }
                                .side-anim { opacity: 0; transform: translateY(20px); transition: all 0.4s ease; }
                                #sci-sidebar.open .side-anim { opacity: 1; transform: translateY(0); }
                                .sb-header { padding: 25px 20px 20px 20px; border-bottom: 1px solid rgba(0,255,65,0.2); display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.4); }
                                .sb-title { color: #00ff41; font-weight: 900; font-size: 16px; letter-spacing: 2px; text-shadow: 0 0 5px #00ff41;}
                                .sb-close { color: #fff; font-size: 26px; cursor: pointer; padding: 0 10px;}
                                .sb-section { padding: 15px 20px; }
                                .sec-head { color: #00ff41; font-size: 11px; font-weight: 900; letter-spacing: 3px; margin-bottom: 12px; border-bottom: 1px solid rgba(0,255,65,0.2); padding-bottom: 8px; text-transform: uppercase;}
                                .sys-row { display: flex; justify-content: space-between; margin-bottom: 12px; align-items: center; background: rgba(0,0,0,0.5); padding: 10px; border-radius: 8px; border-left: 2px solid #00ff41;}
                                .sys-icon { font-size: 16px; margin-right: 10px; }
                                .sys-lbl { color: #aaa; font-size: 12px; font-weight: bold; flex: 1;}
                                .sys-val { color: #fff; font-size: 13px; font-weight: 900; letter-spacing: 1px;}
                                .dev-card { background: linear-gradient(45deg, rgba(0,0,0,0.9), rgba(0,30,0,0.9)); border: 1px solid #00ff41; border-radius: 10px; padding: 20px; text-align: center; margin-bottom: 20px; box-shadow: 0 0 10px rgba(0,255,65,0.2); }
                                .dev-name { color: #00ff41; font-size: 18px; font-weight: 900; letter-spacing: 2px; text-shadow: 0 0 5px #00ff41;}
                                .dev-tg { color: #fff; font-size: 14px; font-weight: 900; margin-top: 8px; letter-spacing: 1px; background: rgba(0,255,65,0.2); padding: 5px; border-radius: 5px;}
                                .social-btn { display: flex; align-items: center; justify-content: center; gap: 12px; width: 100%; padding: 14px; margin-bottom: 12px; border-radius: 8px; font-weight: 900; font-size: 13px; color: #fff; cursor: pointer; letter-spacing: 1.5px; border: none; text-transform: uppercase; }
                                .social-btn:active { transform: scale(0.95); }
                                .sb-tg { background: linear-gradient(90deg, #0088cc, #00bfff); box-shadow: 0 5px 15px rgba(0,136,204,0.3); }
                                #sci-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; background: rgba(0,0,0,0.8); z-index: 9999998; opacity: 0; display: none; backdrop-filter: blur(4px); transition: opacity 0.4s; }
                            `;
                            document.head.appendChild(style);

                            var banner = document.createElement('div');
                            banner.id = 'clean-pro-banner';
                            banner.innerHTML = `
                                <canvas id="matrix-bg"></canvas>
                                <div class="hud-top-bar">
                                    <div class="left-group">
                                        <div class="hud-menu-btn" id="btn-open-menu">☰</div>
                                        <div class="dev-badge">DEV: <span>DARK CYBER</span></div>
                                    </div>
                                    <div class="hud-status"><div class="pulse-dot"></div> LIVE SYNC</div>
                                </div>
                                <div class="hud-core">
                                    <div id="locked-view" style="display: flex; flex-direction: column; align-items: center; width: 100%; padding-top: 5px;">
                                        <div class="sys-hang-title"><span class="money-icon">💸</span><span>SYSTEM HANG ...</span><span class="money-icon">💸</span></div>
                                        <button id="btn-deposit" class="deposit-btn">DEPOSIT TO UNLOCK</button>
                                        <div class="period-text">Period :- <span id="ui-locked-period">CONNECTING...</span></div>
                                        <div class="name-text">DEVELOPER :- DARK CYBER</div>
                                    </div>
                                    <div id="unlocked-view" style="display: none; flex-direction: column; align-items: center; width: 100%; padding-top: 5px;">
                                        <div class="hud-result-wrap">
                                            <div class="hud-res-text" id="ui-result" style="color: #555;">WAIT</div>
                                            <div class="hud-nums-wrap" id="ui-nums">
                                                <div class="h-ball" style="border-color:#555; color:#555;">-</div><div class="h-ball" style="border-color:#555; color:#555;">-</div><div class="h-ball" style="border-color:#555; color:#555;">-</div>
                                            </div>
                                        </div>
                                        <div class="period-text">Period :- <span id="ui-unlocked-period">CONNECTING...</span></div>
                                        <div class="name-text">DEVELOPER :- DARK CYBER</div>
                                    </div>
                                </div>
                                <div id="hud-glow-line"></div>
                            `;
                            document.body.appendChild(banner);

                            var overlay = document.createElement('div');
                            overlay.id = 'sci-overlay';
                            document.body.appendChild(overlay);

                            var sidebar = document.createElement('div');
                            sidebar.id = 'sci-sidebar';
                            sidebar.innerHTML = `
                                <div class="sb-header">
                                    <div class="sb-title">⚙️ DARK CYBER SYS</div>
                                    <div class="sb-close" id="btn-close-menu">✖</div>
                                </div>
                                <div class="sb-section side-anim" style="transition-delay: 0.1s; padding-bottom: 0;">
                                    <div class="sec-head">USER & WALLET DATA</div>
                                    <div class="sys-row"><span class="sys-icon">🆔</span><span class="sys-lbl">UID</span> <span class="sys-val" id="sys-uid">Scan...</span></div>
                                    <div class="sys-row"><span class="sys-icon">💰</span><span class="sys-lbl">WALLET</span> <span class="sys-val" id="sys-balance" style="color: #f0a500;">₹ 0.00</span></div>
                                </div>
                                <div class="sb-section side-anim" style="transition-delay: 0.2s; padding-bottom: 0;">
                                    <div class="sec-head">DEVICE DIAGNOSTICS</div>
                                    <div class="sys-row"><span class="sys-icon">📱</span><span class="sys-lbl">MODEL</span> <span class="sys-val" id="sys-model">Scan...</span></div>
                                    <div class="sys-row"><span class="sys-icon">🔋</span><span class="sys-lbl">BATTERY</span> <span class="sys-val" id="sys-batt">--%</span></div>
                                </div>
                                <div class="sb-section side-anim" style="transition-delay: 0.3s;">
                                    <div class="sec-head">DEVELOPER NETWORK</div>
                                    <div class="dev-card">
                                        <div class="dev-name">DARK CYBER</div>
                                        <div class="dev-tg">VIP HACK</div>
                                    </div>
                                    <button class="social-btn sb-tg" onclick="window.location.href='https://t.me/+0OEWGD1eZO1hNzE1'">✈️ TELEGRAM</button>
                                </div>
                            `;
                            document.body.appendChild(sidebar);

                            // SIDEBAR LOGIC
                            document.getElementById('btn-open-menu').addEventListener('click', function(e) {
                                e.stopPropagation(); sidebar.classList.add('open'); overlay.style.display = 'block'; setTimeout(function() { overlay.style.opacity = '1'; }, 10);
                            });
                            
                            function closeSidebar() { 
                                sidebar.classList.remove('open'); overlay.style.opacity = '0'; setTimeout(function() { overlay.style.display = 'none'; }, 400);
                            }
                            
                            document.getElementById('btn-close-menu').addEventListener('click', closeSidebar);
                            overlay.addEventListener('click', closeSidebar);

                            var uAgent = navigator.userAgent; var devName = "Android OS";
                            if(uAgent.indexOf("Android") > -1) { 
                                var m = uAgent.match(/Android\s([^\;]*)/);
                                if(m) devName = "Android " + m[1]; 
                            }
                            document.getElementById('sys-model').innerText = devName;
                            
                            if (navigator.getBattery) {
                                navigator.getBattery().then(function(battery) {
                                    var bLevel = Math.round(battery.level * 100); 
                                    var bEl = document.getElementById('sys-batt');
                                    bEl.innerText = bLevel + '% ' + (battery.charging ? '⚡' : '');
                                    bEl.style.color = bLevel < 20 ? '#d90000' : '#00ff41';
                                    battery.addEventListener('levelchange', function() { 
                                        bEl.innerText = Math.round(battery.level * 100) + '%'; 
                                    });
                                });
                            } else { document.getElementById('sys-batt').innerText = '92% ⚡'; }

                            document.getElementById('btn-deposit').addEventListener('click', function() {
                                // Yaha deposit button dabane par voice play hogi aur link update kar diya hai
                                AndroidApp.playDepositClickVoice();
                                setTimeout(function() { window.location.href = 'https://www.jaiclub39.com/#/wallet/Recharge'; }, 500); 
                            });

                            // SMART WALLET BALANCE SCANNER
                            var isUnlocked = localStorage.getItem('hack_unlocked_status') === 'true';
                            var savedInit = localStorage.getItem('init_wallet_balance');
                            var initialBalance = savedInit !== null ? parseFloat(savedInit) : -1;
                            var scanCount = 0;
                            
                            if(isUnlocked) {
                                document.getElementById('locked-view').style.display = 'none';
                                document.getElementById('unlocked-view').style.display = 'flex';
                            }

                            function getLiveUID() {
                                var match = document.body.innerText.match(/(?:UID|ID)[\s|:]*(\d{4,12})/i);
                                return match ? match[1] : "HIDDEN";
                            }

                            function getLiveBalance() {
                                var text = document.body.innerText;
                                var match = text.match(/Total balance[\s\S]{0,30}?₹\s*([0-9.,]+)/i);
                                if (match) return parseFloat(match[1].replace(/,/g, ''));
                                
                                var match2 = text.match(/(?:Balance|Wallet)[\s\S]{0,30}?₹\s*([0-9.,]+)/i);
                                if (match2) return parseFloat(match2[1].replace(/,/g, ''));
                                
                                var matches = text.match(/₹\s*([0-9.,]+)/g);
                                if (matches) {
                                    for(var i=0; i<matches.length; i++) {
                                        var val = parseFloat(matches[i].replace(/[^\d.]/g, ''));
                                        if (val !== 100 && val !== 500 && val !== 1000 && val !== 5000) return val;
                                    }
                                }
                                return -1;
                            }

                            function scanSystemData() {
                                var liveBal = getLiveBalance();
                                var liveUID = getLiveUID();
                                
                                document.getElementById('sys-uid').innerText = liveUID;
                                var balEl = document.getElementById('sys-balance');
                                balEl.innerText = liveBal >= 0 ? '₹ ' + liveBal : 'Scanning...';
                                balEl.style.color = liveBal > 0 ? '#00ff41' : '#f0a500';

                                if(isUnlocked) return;
                                
                                var currentUrl = window.location.href.toLowerCase();
                                if(currentUrl.includes('recharge') || currentUrl.includes('deposit') || currentUrl.includes('pay')) return; 

                                if (liveBal >= 0) {
                                    scanCount++;
                                    if (initialBalance === -1) {
                                        if(scanCount > 3) { 
                                            initialBalance = liveBal;
                                            localStorage.setItem('init_wallet_balance', liveBal);
                                        }
                                    } else {
                                        var diff = liveBal - initialBalance;
                                        if (diff >= 100) { 
                                            isUnlocked = true;
                                            localStorage.setItem('hack_unlocked_status', 'true');
                                            document.getElementById('locked-view').style.display = 'none';
                                            document.getElementById('unlocked-view').style.display = 'flex';
                                            // Deposit success hone par voice bajegi
                                            AndroidApp.playDepositVoice();
                                            AndroidApp.showToast("Payment Verified! Wallet Balance Increased. Hack Unlocked.");
                                        } else if (liveBal < initialBalance) {
                                            initialBalance = liveBal;
                                            localStorage.setItem('init_wallet_balance', liveBal);
                                        }
                                    }
                                }
                            }
    
                            setInterval(scanSystemData, 1500);

                            // MATRIX BACKGROUND
                            var canvas = document.getElementById('matrix-bg');
                            var ctx = canvas.getContext('2d');
                            canvas.width = window.innerWidth;
                            canvas.height = 205;
                            var matrixChars = "01".split("");
                            var font_size = 12;
                            var columns = canvas.width / font_size;
                            var drops = [];
                            
                            for(var x = 0; x < columns; x++) drops[x] = 1;
                            
                            function drawMatrix() {
                                ctx.fillStyle = "rgba(0, 0, 0, 0.15)";
                                ctx.fillRect(0, 0, canvas.width, canvas.height);
                                ctx.fillStyle = "#00ff41";
                                ctx.font = font_size + "px monospace";
                                for(var i = 0; i < drops.length; i++) {
                                    var text = matrixChars[Math.floor(Math.random() * matrixChars.length)];
                                    ctx.fillText(text, i * font_size, drops[i] * font_size);
                                    if(drops[i] * font_size > canvas.height && Math.random() > 0.95) drops[i] = 0;
                                    drops[i]++;
                                }
                            }
                            setInterval(drawMatrix, 40);

                            // PREDICTION ALGORITHM
                            var PRO_LOGIC = {
                                1: { number: '0/2/4', size: 'SMALL', color: '#00ff41', shadow: '0 0 15px #00ff41' },
                                2: { number: '0/7/4', size: 'SMALL', color: '#00ff41', shadow: '0 0 15px #00ff41' },
                                3: { number: '7/1/9', size: 'BIGG',  color: '#ff003c', shadow: '0 0 15px #ff003c' },
                                4: { number: '6/8/2', size: 'BIGG',  color: '#ff003c', shadow: '0 0 15px #ff003c' },
                                5: { number: '5/9/3', size: 'BIGG',  color: '#ff003c', shadow: '0 0 15px #ff003c' },
                                6: { number: '5/7/0', size: 'BIGG',  color: '#ff003c', shadow: '0 0 15px #ff003c' },
                                7: { number: '0/2/8', size: 'SMALL', color: '#00ff41', shadow: '0 0 15px #00ff41' },
                                8: { number: '4/6/1', size: 'SMALL', color: '#00ff41', shadow: '0 0 15px #00ff41' },
                                9: { number: '1/3/9', size: 'SMALL', color: '#00ff41', shadow: '0 0 15px #00ff41' },
                                0: { number: '5/9/7', size: 'BIGG',  color: '#ff003c', shadow: '0 0 15px #ff003c' }
                            };
                            
                            var lastPeriod = null;
                            
                            function getFallbackPeriod() {
                                var d = new Date();
                                var y = d.getFullYear(); var m = String(d.getMonth() + 1).padStart(2, '0');
                                var day = String(d.getDate()).padStart(2, '0');
                                var mins = (d.getHours() * 60) + d.getMinutes() + 1;
                                return y + m + day + "1" + String(mins).padStart(4, '0');
                            }

                            function processPeriodData(p) {
                                if (p !== lastPeriod) {
                                    lastPeriod = p;
                                    var pLockedEl = document.getElementById('ui-locked-period');
                                    var pUnlockedEl = document.getElementById('ui-unlocked-period');
                                    if(pLockedEl) pLockedEl.innerText = p;
                                    if(pUnlockedEl) pUnlockedEl.innerText = p;
                                    
                                    var lastDigit = parseInt(p.slice(-1));
                                    var prediction = PRO_LOGIC[lastDigit] || PRO_LOGIC[0];
                                    
                                    var resEl = document.getElementById('ui-result');
                                    if(resEl) {
                                        resEl.innerText = prediction.size;
                                        resEl.style.color = prediction.color;
                                        resEl.style.textShadow = prediction.shadow;
                                    }
                                    
                                    var numHtml = "";
                                    if(prediction.number) {
                                        var numArr = prediction.number.split('/');
                                        for(var i=0; i<numArr.length; i++) {
                                            numHtml += "<div class='h-ball' style='border-color:" + prediction.color + "; color:" + prediction.color + "; box-shadow: " + prediction.shadow + ";'><span>" + numArr[i] + "</span></div>";
                                        }
                                    }
                                    var numEl = document.getElementById('ui-nums');
                                    if(numEl) numEl.innerHTML = numHtml;
                                }
                            }

                            function fetchRealPeriod() {
                                try {
                                    fetch('https://api.bdg88zf.com/api/webapi/GetGameIssue', { 
                                        method: 'POST', headers: { 'Content-Type': 'application/json' }, 
                                        body: JSON.stringify({ typeId: 1, language: 0, random: "40079dcba93a48769c6ee9d4d4fae23f", signature: "D12108C4F57C549D82B23A91E0FA20AE", timestamp: 1727792520 }) 
                                    })
                                    .then(function(r){ return r.json(); })
                                    .then(function(data) {
                                        if (data && data.data && data.data.issueNumber) {
                                            processPeriodData(data.data.issueNumber.toString());
                                        } else { processPeriodData(getFallbackPeriod()); }
                                    }).catch(function(e) { processPeriodData(getFallbackPeriod()); });
                                } catch(err) { processPeriodData(getFallbackPeriod()); }
                            }

                            setInterval(fetchRealPeriod, 3000);
                        }
                    })();
                """.trimIndent()
                view?.evaluateJavascript(jsCode, null)
            }
        }
        webView.loadUrl(registerUrl)
    }

    // VOICES FUNCTIONS (Yaha se aawazein play hoti hain)
    fun playVoice() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(this, R.raw.my_voice)
            mediaPlayer?.start()
        } catch (e: Exception) {}
    }

    fun playDepositVoice() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(this, R.raw.deposit_voice)
            mediaPlayer?.start()
        } catch (e: Exception) {}
    }

    fun playDepositClickAudio() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(this, R.raw.deposit_voice)
            mediaPlayer?.start()
        } catch (e: Exception) {}
    }

    // JAVASCRIPT TO ANDROID BRIDGE
    inner class WebAppInterface {
        @JavascriptInterface
        fun playWarningVoice() { runOnUiThread { playVoice() } }

        @JavascriptInterface
        fun playDepositVoice() { runOnUiThread { this@MainActivity.playDepositVoice() } }

        @JavascriptInterface
        fun playDepositClickVoice() { runOnUiThread { this@MainActivity.playDepositClickAudio() } }

        @JavascriptInterface
        fun showToast(msg: String) { runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() } }
    }

    override fun onBackPressed() {
        val webView = findViewById<WebView>(R.id.webView)
        val currentUrl = webView.url?.lowercase() ?: ""

        if (currentUrl.contains("register") || currentUrl.contains("login")) {
            Toast.makeText(this, "⚠️ Please register to continue", Toast.LENGTH_SHORT).show()
            return
        }

        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}